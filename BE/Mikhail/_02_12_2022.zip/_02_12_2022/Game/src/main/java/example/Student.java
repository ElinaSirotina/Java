package example;

public class Student extends Participant{
    public Student(String name, int age) {
        super(name, age);
    }
}
