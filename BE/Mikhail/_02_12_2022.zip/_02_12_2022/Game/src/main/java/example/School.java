package example;

public class School extends Participant{
    public School(String name, int age) {
        super(name, age);
    }
}
