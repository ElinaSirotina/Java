package paramMethod;

import java.util.ArrayList;

public class ParametrizedMethodEx1 {
    public static void main(String[] args) {
        ArrayList<Integer> list = new ArrayList<>();
        //ArrayList list = new ArrayList<>(); compilator
        int i = list.get(0);
        //int i = (Integer) list.get(0); compilator
    }



}

