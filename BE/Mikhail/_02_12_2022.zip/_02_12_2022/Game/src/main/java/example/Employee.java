package example;

public class Employee extends Participant {
    public Employee(String name, int age) {
        super(name, age);
    }
}
