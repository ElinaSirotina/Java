package de.telran.practice2;

public interface Moving {
    void move();
}
