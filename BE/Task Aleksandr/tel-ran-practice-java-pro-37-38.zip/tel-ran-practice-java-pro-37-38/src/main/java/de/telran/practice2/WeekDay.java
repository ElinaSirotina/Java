package de.telran.practice2;

public enum WeekDay {
    MONDAY("Понедельник", 1),
    TUESDAY("Вторник", 2),
    WEDNESDAY("Среда", 3),
    THURSDAY("Четверг", 4);

    WeekDay(String ruName, int dayNumber) {
    }

    WeekDay() {
    }
}
