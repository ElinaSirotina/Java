package de.telran.practice2;

public interface MovingAndAttacking extends Moving, Attacking {
}
