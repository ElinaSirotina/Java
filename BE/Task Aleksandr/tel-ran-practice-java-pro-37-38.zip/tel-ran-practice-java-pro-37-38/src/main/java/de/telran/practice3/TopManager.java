package de.telran.practice3;

public class TopManager extends Employee {

    public TopManager(String name) {
        super(name, PositionType.TOP);
    }
}
