package de.telran.practice2;

public class Plane implements Moving {
    @Override
    public void move() {
        System.out.println("Plane fly");
    }
}
