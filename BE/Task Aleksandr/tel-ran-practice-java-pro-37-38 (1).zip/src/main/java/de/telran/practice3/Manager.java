package de.telran.practice3;

public class Manager extends Employee {

    public Manager(String name) {
        super(name, PositionType.MANAGER);
    }
}
