package de.telran.practice4;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public class LombokTestClass {
    private int num;
    private String str;
}
