package de.telran.practice1;

public enum AnimalType {

}
