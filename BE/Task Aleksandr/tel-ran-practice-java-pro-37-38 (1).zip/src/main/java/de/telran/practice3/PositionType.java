package de.telran.practice3;

public enum PositionType {
    MANAGER,
    TOP,
    PRIVATE
}
