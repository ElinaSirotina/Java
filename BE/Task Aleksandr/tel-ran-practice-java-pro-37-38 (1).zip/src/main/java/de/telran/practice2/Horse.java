package de.telran.practice2;

public class Horse implements Moving {
    @Override
    public void move() {
        System.out.println("Horse run");
    }
}
