package de.telran.practice3;

public class PrivateEmployee extends Employee {

    public PrivateEmployee(String name) {
        super(name, PositionType.PRIVATE);
    }
}
