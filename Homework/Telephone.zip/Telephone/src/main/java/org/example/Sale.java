package org.example;

public interface Sale {
    public void isSale();
}
