package org.example;

public interface Stilus {
    public void includeStilus();
    public void supportStilus();
}
