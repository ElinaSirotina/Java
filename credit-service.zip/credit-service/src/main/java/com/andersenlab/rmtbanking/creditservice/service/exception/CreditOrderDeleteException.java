package com.andersenlab.rmtbanking.creditservice.service.exception;

public class CreditOrderDeleteException extends RuntimeException {

    public CreditOrderDeleteException(String message) {
        super(message);
    }
}
