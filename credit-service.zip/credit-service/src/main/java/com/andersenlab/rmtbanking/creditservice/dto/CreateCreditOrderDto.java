package com.andersenlab.rmtbanking.creditservice.dto;

import com.andersenlab.rmtbanking.creditservice.validation.annotation.*;
import lombok.Value;

import java.math.BigDecimal;
import java.math.BigInteger;

@Value
public class CreateCreditOrderDto {

    @PositiveInteger
    BigInteger productId;

    @PositiveDecimal
    BigDecimal amount;

    @PositiveInteger
    BigInteger periodMonths;

    @PositiveDecimal
    BigDecimal monthlyIncome;

    @PositiveDecimal
    BigDecimal monthlyExpenditure;

    @Ein
    String employerIdentificationNumber;

}
