package com.andersenlab.rmtbanking.creditservice.controller;

import com.andersenlab.rmtbanking.creditservice.dto.ProductDto;
import com.andersenlab.rmtbanking.creditservice.dto.ProductListDto;
import com.andersenlab.rmtbanking.creditservice.service.ProductService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.math.BigInteger;

@RestController
@RequestMapping("/auth")
@RequiredArgsConstructor
public class ProductsController {

    private final ProductService productService;

    @GetMapping("/credit-products/{productId}")
    @ResponseStatus(HttpStatus.OK)
    public ProductDto getInfoAboutProduct(@PathVariable BigInteger productId) {
        return productService.getProductById(productId);
    }

    @GetMapping("/credit-products")
    @ResponseStatus(HttpStatus.OK)
    public ProductListDto getAllProducts() {
        return productService.getAllProductsActive();
    }
}