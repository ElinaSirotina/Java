package com.andersenlab.rmtbanking.creditservice.service.impl;

import com.andersenlab.rmtbanking.creditservice.dto.CreateCreditOrderDto;
import com.andersenlab.rmtbanking.creditservice.dto.CreditOrderAfterCreateDto;
import com.andersenlab.rmtbanking.creditservice.dto.DeleteCreditOrderRequestDto;
import com.andersenlab.rmtbanking.creditservice.validation.entity.CreditOrder;
import com.andersenlab.rmtbanking.creditservice.validation.entity.enums.CreditOrderStatus;
import com.andersenlab.rmtbanking.creditservice.mapper.CreditOrderMapper;
import com.andersenlab.rmtbanking.creditservice.repository.CreditOrderRepository;
import com.andersenlab.rmtbanking.creditservice.repository.ProductRepository;
import com.andersenlab.rmtbanking.creditservice.service.CreditOrderService;
import com.andersenlab.rmtbanking.creditservice.service.exception.CreditOrderDeleteException;
import com.andersenlab.rmtbanking.creditservice.service.exception.ErrorMessage;
import com.andersenlab.rmtbanking.creditservice.service.exception.ProductNotFoundException;
import com.andersenlab.rmtbanking.creditservice.service.util.ServiceUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigInteger;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
public class CreditOrderServiceImpl implements CreditOrderService {

    private final CreditOrderRepository creditOrderRepository;
    private final ProductRepository productRepository;
    private final CreditOrderMapper mapper;
    private final ServiceUtil serviceUtil;

    @Override
    @Transactional
    public CreditOrderAfterCreateDto createCreditOrder(CreateCreditOrderDto dto, String clientId) {
        checkProductId(dto.getProductId());
        CreditOrder creditOrder = mapper.dtoToCreditOrder(dto, UUID.fromString(clientId));
        creditOrder.setNumber(serviceUtil.createNumberForCreditOrder());
        log.info("Create credit order {}", creditOrder);
        creditOrderRepository.save(creditOrder);
        return mapper.creditOrderToDto(creditOrder);
    }

    private void checkProductId(BigInteger productId) {
        log.info("Check existence of product with id {}", productId);
        productRepository.findProductById(productId).orElseThrow(
                () -> new ProductNotFoundException(ErrorMessage.CREDIT_PRODUCT_NOT_FOUND));
    }

    @Override
    @Transactional
    public void deleteCreditOrder(DeleteCreditOrderRequestDto dto, String clientId) {
        checkCreditOrder(dto);
        log.info("Delete credit order by client id {} and order id {}", clientId, dto.getId());
        creditOrderRepository.deleteCreditOrderByIdAndClientId(UUID.fromString(dto.getId()), UUID.fromString(clientId));
    }

    private void checkCreditOrder(DeleteCreditOrderRequestDto dto)  {
        log.info("Check existence of credit order with id {}", dto.getId());
        creditOrderRepository.findById(UUID.fromString(dto.getId()))
                .filter(this::checkCreditOrderStatus)
                .orElseThrow(() -> new CreditOrderDeleteException(ErrorMessage.CREDIT_ORDER_STATUS));
    }

    private boolean checkCreditOrderStatus(CreditOrder creditOrder) {
        log.info("Check status of credit order with id {}", creditOrder.getId());
        return creditOrder.getStatus().equals(CreditOrderStatus.IN_REVIEW) ||
                creditOrder.getStatus().equals(CreditOrderStatus.ACCEPTED);
    }
}