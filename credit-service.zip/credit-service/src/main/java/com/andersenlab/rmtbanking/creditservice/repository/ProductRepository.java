package com.andersenlab.rmtbanking.creditservice.repository;

import com.andersenlab.rmtbanking.creditservice.validation.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.math.BigInteger;
import java.util.List;
import java.util.Optional;

public interface ProductRepository extends JpaRepository<Product, BigInteger> {

    Optional<Product> findProductById(BigInteger id);

    List<Product> getAllByActive(Boolean active);
}