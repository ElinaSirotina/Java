package com.andersenlab.rmtbanking.creditservice.service;

import com.andersenlab.rmtbanking.creditservice.dto.ProductDto;
import com.andersenlab.rmtbanking.creditservice.dto.ProductListDto;

import java.math.BigInteger;

public interface ProductService {

    ProductDto getProductById(BigInteger id);

    ProductListDto getAllProductsActive();
}