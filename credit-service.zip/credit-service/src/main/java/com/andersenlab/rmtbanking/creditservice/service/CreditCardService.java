package com.andersenlab.rmtbanking.creditservice.service;

import com.andersenlab.rmtbanking.creditservice.dto.CreditCardDto;
import com.andersenlab.rmtbanking.creditservice.dto.CreditCardInfoDto;

import java.util.List;

public interface CreditCardService {

    List<CreditCardDto> getCreditCardList(String clientId);
    CreditCardInfoDto getOneCreditCardInfo(String cardId);
}