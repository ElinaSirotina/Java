package com.andersenlab.rmtbanking.creditservice.dto;

import com.andersenlab.rmtbanking.creditservice.validation.entity.enums.CalculationMode;
import lombok.Value;

import java.math.BigDecimal;
import java.math.BigInteger;

@Value
public class ProductDto {

    BigInteger id;
    String name;
    BigDecimal minSum;
    BigDecimal maxSum;
    String currencyCode;
    BigDecimal minInterestRate;
    BigDecimal maxInterestRate;
    boolean needGuarantees;
    boolean deliveryInCash;
    boolean earlyRepayment;
    boolean needIncomeDetails;
    Integer minPeriodMonths;
    Integer maxPeriodMonths;
    boolean active;
    String details;
    CalculationMode calculationMode;
    Integer gracePeriodMonths;
    boolean rateIsAdjustable;
    String rateBase;
    BigDecimal rateFixPart;
    BigDecimal increasedRate;
}