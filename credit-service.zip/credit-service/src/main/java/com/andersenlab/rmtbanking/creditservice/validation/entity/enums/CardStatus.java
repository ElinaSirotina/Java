package com.andersenlab.rmtbanking.creditservice.validation.entity.enums;

public enum CardStatus {

    ACTIVE,
    BLOCKED,
    EXPIRED
}
