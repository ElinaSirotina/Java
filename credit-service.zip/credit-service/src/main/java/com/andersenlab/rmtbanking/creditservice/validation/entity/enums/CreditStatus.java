package com.andersenlab.rmtbanking.creditservice.validation.entity.enums;

public enum CreditStatus {

    IN_REVIEW,
    DECLINED,
    ACTIVE,
    CLOSED
}
