package com.andersenlab.rmtbanking.creditservice.dto;

import com.andersenlab.rmtbanking.creditservice.validation.annotation.Uuid;
import lombok.Value;

@Value
public class DeleteCreditOrderRequestDto {

    @Uuid
    String id;
}
