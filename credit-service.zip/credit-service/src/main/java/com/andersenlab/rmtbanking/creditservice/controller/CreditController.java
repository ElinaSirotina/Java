package com.andersenlab.rmtbanking.creditservice.controller;

import com.andersenlab.rmtbanking.creditservice.dto.PaymentsScheduleDto;
import com.andersenlab.rmtbanking.creditservice.service.CreditService;
import com.andersenlab.rmtbanking.creditservice.validation.annotation.Uuid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@Validated
@RestController
@RequestMapping("/auth/credits")
@RequiredArgsConstructor
public class CreditController {

    private final CreditService creditService;

    @GetMapping("/{creditId}/schedule")
    @ResponseStatus(HttpStatus.OK)
    public PaymentsScheduleDto getCreditPaymentsSchedule(@Uuid @PathVariable("creditId") String creditId) {
        return creditService.getCreditPaymentsSchedule(creditId);
    }
}