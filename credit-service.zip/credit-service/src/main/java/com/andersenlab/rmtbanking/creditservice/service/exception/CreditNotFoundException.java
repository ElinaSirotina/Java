package com.andersenlab.rmtbanking.creditservice.service.exception;

public class CreditNotFoundException extends RuntimeException {

    public CreditNotFoundException(String message) {
        super(message);
    }
}
