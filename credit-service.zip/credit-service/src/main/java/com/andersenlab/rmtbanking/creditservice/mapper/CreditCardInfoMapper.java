package com.andersenlab.rmtbanking.creditservice.mapper;

import com.andersenlab.rmtbanking.creditservice.dto.CreditCardInfoDto;
import com.andersenlab.rmtbanking.creditservice.validation.entity.Card;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring")
public interface CreditCardInfoMapper {
    @Mapping(source = "account.accountNumber", target = "accountNumber")
    @Mapping(source = "account.principalDebt", target = "principalDebt")
    @Mapping(source = "account.credit.creditOrder.product.name", target = "name")
    @Mapping(source = "account.credit.creditLimit", target = "creditLimit")
    @Mapping(source = "account.credit.currencyCode", target = "currencyCode")
    @Mapping(source = "account.credit.agreement.terminationDate", target = "terminationDate")
    CreditCardInfoDto creditCardInfoToDto(Card cardId);
}