package com.andersenlab.rmtbanking.creditservice.service.impl;

import com.andersenlab.rmtbanking.creditservice.dto.ProductDto;
import com.andersenlab.rmtbanking.creditservice.dto.ProductListDto;
import com.andersenlab.rmtbanking.creditservice.mapper.ProductMapper;
import com.andersenlab.rmtbanking.creditservice.repository.ProductRepository;
import com.andersenlab.rmtbanking.creditservice.service.ProductService;
import com.andersenlab.rmtbanking.creditservice.service.exception.ErrorMessage;
import com.andersenlab.rmtbanking.creditservice.service.exception.ProductNotFoundException;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigInteger;

@Service
@RequiredArgsConstructor
@Slf4j
public class ProductServiceImpl implements ProductService {

    private final ProductRepository productRepository;
    private final ProductMapper productMapper;

    @Override
    @Transactional(readOnly = true)
    public ProductDto getProductById(BigInteger id) {
        log.info("Get product with id {}", id);
        return productMapper.toDto(productRepository.findProductById(id).orElseThrow(
                () -> new ProductNotFoundException
                        ((ErrorMessage.CREDIT_PRODUCT_NOT_FOUND))));
    }

    public ProductListDto getAllProductsActive() {
        log.info("Get all active products");
        return new ProductListDto
                (productMapper.productsToProductsDto
                        (productRepository.getAllByActive(true)));
    }
}