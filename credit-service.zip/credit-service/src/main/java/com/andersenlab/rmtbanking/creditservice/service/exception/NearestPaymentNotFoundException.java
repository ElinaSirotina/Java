package com.andersenlab.rmtbanking.creditservice.service.exception;

public class NearestPaymentNotFoundException extends RuntimeException {

    public NearestPaymentNotFoundException(String message) {
        super(message);
    }
}
