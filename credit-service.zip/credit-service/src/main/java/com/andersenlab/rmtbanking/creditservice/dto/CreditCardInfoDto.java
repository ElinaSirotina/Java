package com.andersenlab.rmtbanking.creditservice.dto;

import lombok.Value;

@Value
public class CreditCardInfoDto {

    String accountNumber;
    String principalDebt;
    String name;
    String creditLimit;
    String currencyCode;
    String terminationDate;
    String holderName;
    String expirationDate;
    String balance;
    String transactionLimit;
    String paymentSystem;
    String status;
}