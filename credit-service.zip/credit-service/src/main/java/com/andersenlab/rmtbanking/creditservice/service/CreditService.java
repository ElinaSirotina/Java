package com.andersenlab.rmtbanking.creditservice.service;

import com.andersenlab.rmtbanking.creditservice.dto.PaymentsScheduleDto;

public interface CreditService {

    PaymentsScheduleDto getCreditPaymentsSchedule(String creditId);
}
