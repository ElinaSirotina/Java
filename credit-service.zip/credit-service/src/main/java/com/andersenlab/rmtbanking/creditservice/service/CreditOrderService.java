package com.andersenlab.rmtbanking.creditservice.service;

import com.andersenlab.rmtbanking.creditservice.dto.CreateCreditOrderDto;
import com.andersenlab.rmtbanking.creditservice.dto.CreditOrderAfterCreateDto;
import com.andersenlab.rmtbanking.creditservice.dto.DeleteCreditOrderRequestDto;

public interface CreditOrderService {

    CreditOrderAfterCreateDto createCreditOrder(CreateCreditOrderDto createCreditOrderDto, String clientId);

    void deleteCreditOrder(DeleteCreditOrderRequestDto dto, String clientId);

}
