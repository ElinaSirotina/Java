package com.andersenlab.rmtbanking.creditservice.service.impl;

import com.andersenlab.rmtbanking.creditservice.dto.CreditCardDto;
import com.andersenlab.rmtbanking.creditservice.dto.CreditCardInfoDto;
import com.andersenlab.rmtbanking.creditservice.validation.entity.enums.CardStatus;
import com.andersenlab.rmtbanking.creditservice.mapper.CreditCardInfoMapper;
import com.andersenlab.rmtbanking.creditservice.mapper.CreditCardMapper;
import com.andersenlab.rmtbanking.creditservice.repository.CreditCardRepository;
import com.andersenlab.rmtbanking.creditservice.service.CreditCardService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
public class CreditCardServiceImpl implements CreditCardService {

    private final CreditCardRepository creditCardRepository;
    private final CreditCardMapper cardMapper;
    private final CreditCardInfoMapper creditCardInfoMapper;

    @Override
    @Transactional(readOnly = true)
    public List<CreditCardDto> getCreditCardList(String clientId) {
        log.info("Get list of credit cards for client with id {}", clientId);
        return cardMapper.cardsToCardsDto(creditCardRepository
                .getCardsByStatusAndClientId(CardStatus.ACTIVE, UUID.fromString(clientId)));
    }

    @Override
    @Transactional(readOnly = true)
    public CreditCardInfoDto getOneCreditCardInfo(String cardId) {
        log.info("Get information about credit card with id {}", cardId);
        return creditCardInfoMapper.creditCardInfoToDto(creditCardRepository.getCardById(UUID.fromString(cardId)));
    }
}