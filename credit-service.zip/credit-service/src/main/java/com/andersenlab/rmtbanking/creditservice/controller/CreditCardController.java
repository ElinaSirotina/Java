package com.andersenlab.rmtbanking.creditservice.controller;

import com.andersenlab.rmtbanking.creditservice.dto.CreditCardInfoDto;
import com.andersenlab.rmtbanking.creditservice.service.CreditCardService;
import com.andersenlab.rmtbanking.creditservice.validation.annotation.Uuid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@Validated
@RestController
@RequestMapping("/auth/credit-cards")
@RequiredArgsConstructor
public class CreditCardController {

    private final CreditCardService creditCardService;

    @GetMapping("/info/{cardId}")
    @ResponseStatus(HttpStatus.OK)
    public CreditCardInfoDto getCreditCardInfo(@Uuid @PathVariable String cardId) {
        return creditCardService.getOneCreditCardInfo(cardId);
    }
}