package com.andersenlab.rmtbanking.creditservice.repository;

import com.andersenlab.rmtbanking.creditservice.validation.entity.CreditOrder;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface CreditOrderRepository extends JpaRepository<CreditOrder, UUID> {
    void deleteCreditOrderByIdAndClientId(UUID creditOrderId, UUID clientId);
}