package com.andersenlab.rmtbanking.creditservice.validation.entity.enums;

public enum CreditOrderStatus {

    ACCEPTED,
    IN_REVIEW,
    DECLINED,
    APPROVED
}
