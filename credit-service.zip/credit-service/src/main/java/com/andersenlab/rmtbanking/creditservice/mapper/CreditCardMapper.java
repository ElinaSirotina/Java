package com.andersenlab.rmtbanking.creditservice.mapper;

import com.andersenlab.rmtbanking.creditservice.dto.CreditCardDto;
import com.andersenlab.rmtbanking.creditservice.validation.entity.Card;
import com.andersenlab.rmtbanking.creditservice.validation.entity.PaymentSchedule;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;

import static org.mapstruct.InjectionStrategy.CONSTRUCTOR;

@Mapper(componentModel = "spring", injectionStrategy = CONSTRUCTOR,
        uses = {UuidMapper.class, PaymentScheduleMapper.class},
        imports = {PaymentSchedule.class, Comparator.class, LocalDate.class})
public interface CreditCardMapper {

    @Mapping(source = "id", target = "cardId")
    @Mapping(source = "account.credit.creditLimit", target = "creditLimit")
    @Mapping(source = "account.credit.interestRate", target = "interestRate")
    @Mapping(source = "account.principalDebt", target = "principalDebt")
    @Mapping(source = "account.interestDebt", target = "interestDebt")
    @Mapping(source = "account", target = "paymentDate")
    @Mapping(source = "account", qualifiedByName = "getPrincipal", target = "paymentPrincipal")
    @Mapping(source = "account", qualifiedByName = "getInterest", target = "paymentInterest")
    @Mapping(source = "card.account.accountNumber", target = "accountNumber")
    CreditCardDto toDto(Card card);

    List<CreditCardDto> cardsToCardsDto(List<Card> cards);
}